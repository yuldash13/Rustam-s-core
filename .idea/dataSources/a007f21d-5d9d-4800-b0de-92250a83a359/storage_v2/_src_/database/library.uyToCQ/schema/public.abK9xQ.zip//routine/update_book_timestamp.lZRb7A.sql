create function update_book_timestamp() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

alter function update_book_timestamp() owner to library;

