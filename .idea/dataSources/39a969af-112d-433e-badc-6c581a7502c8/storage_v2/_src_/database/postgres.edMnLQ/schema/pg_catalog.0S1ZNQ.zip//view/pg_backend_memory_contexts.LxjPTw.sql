create view pg_backend_memory_contexts
            (name, ident, type, level, path, total_bytes, total_nblocks, free_bytes, free_chunks, used_bytes) as
SELECT name,
       ident,
       type,
       level,
       path,
       total_bytes,
       total_nblocks,
       free_bytes,
       free_chunks,
       used_bytes
FROM pg_get_backend_memory_contexts() pg_get_backend_memory_contexts(name, ident, type, level, path, total_bytes,
                                                                     total_nblocks, free_bytes, free_chunks,
                                                                     used_bytes);

alter table pg_backend_memory_contexts
    owner to postgres;

grant select on pg_backend_memory_contexts to pg_read_all_stats;

