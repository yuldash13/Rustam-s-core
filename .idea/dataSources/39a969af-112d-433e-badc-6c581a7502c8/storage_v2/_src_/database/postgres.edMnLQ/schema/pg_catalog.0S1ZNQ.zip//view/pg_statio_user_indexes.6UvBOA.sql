create view pg_statio_user_indexes
            (relid, indexrelid, schemaname, relname, indexrelname, idx_blks_read, idx_blks_hit) as
SELECT relid,
       indexrelid,
       schemaname,
       relname,
       indexrelname,
       idx_blks_read,
       idx_blks_hit
FROM pg_statio_all_indexes
WHERE (schemaname <> ALL (ARRAY ['pg_catalog'::name, 'information_schema'::name]))
  AND schemaname !~ '^pg_toast'::text;

alter table pg_statio_user_indexes
    owner to postgres;

grant select on pg_statio_user_indexes to public;

